package com.example.letscodetest.viewmodels

class RegisterUserViewModel:BaseViewModel() {
}