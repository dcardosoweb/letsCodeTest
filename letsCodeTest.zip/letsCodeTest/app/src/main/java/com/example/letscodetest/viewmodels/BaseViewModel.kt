package com.example.letscodetest.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

open class BaseViewModel: ViewModel()
{
    var errorCode: MutableLiveData<String> = MutableLiveData()
    var errorMsg: MutableLiveData<String> = MutableLiveData()
    var infoMsg: MutableLiveData<String> = MutableLiveData()
    var notAuthorized: MutableLiveData<Boolean> = MutableLiveData()
}