package com.example.letscodetest.di

import com.example.letscodetest.viewmodels.RegisterUserViewModel
import org.koin.dsl.module
import org.koin.androidx.viewmodel.dsl.viewModel

val viewModule = module {
    viewModel {
        RegisterUserViewModel(
        )
    }
}