package com.example.letscodetest.entities

class UserEntity(name:String,email:String,password:String) {
}